# Who we call and what we sell

## Who we call: room count decides it

| Size | What we do |
|---|---|
| 8 to 20 rooms | **Call first.** The December Review Sprint. Worth the most of Giorgio's time. |
| 5 to 7 rooms | **Call.** Reviews + WhatsApp, the smaller package. |
| Over 20 rooms, or more than one property | **Call.** Book the walkthrough; Jacques prices it. |
| 4 rooms or fewer | **Skip for now.** Too small to be worth a walkthrough. |
| 300+ reviews and already strong on Google | **Parked.** They don't need us yet. |

If the room count is missing, ask on the call: "How many rooms do you have?"

Giorgio's list (internal, shows which group each place is in):
https://jcereports.netlify.app/google-check-f2c85f/list-8e048fc2.html

## What we sell, in three words: ask, answer, reply

- **Ask:** every guest gets asked for a Google review the day they check out.
- **Answer:** every review gets an answer, so the owner never has to write one again.
- **Reply:** WhatsApp and website chat answer guests' questions, Sundays included.

The line for an owner: "We make sure every guest gets asked, every review gets answered and every WhatsApp gets a reply."

## The bonus (for Giorgio to know, never in writing to a prospect)

As a bonus, we add a **review stand for their reception**, and they get a **discount on additional units** (more stands or cards). Jacques brings it up on the call, after the price.

## Price

On a call, only the range: "We have guesthouses spending about R500 a month and others spending R8,000 a month. Where you'd sit depends on your place." Exact prices, the guarantee and the offer are Jacques's to present on the walkthrough.

## Two lines Giorgio can use

- **Scarcity:** "We're only taking two more guesthouses before mid-December."
- **Urgency:** "To be live and ready for December, we'd need to start by 13 November."

After 13 November, the urgency line becomes: "Let's get you set up so February doesn't stay quiet."

## Never say

- "We'll get your price showing on Google." We can't. If asked: "That's set up through your booking system. We'll check yours as part of setup."
- TO Strand's "8 reviews a week". That's a big resort. A 5-room guesthouse gets maybe 5 to 9 a month.
- "Reviews are what Google ranks on." It's one of three things (relevance, distance, popularity). Say "can help your ranking".
- Anything from the internal list: scores, groups, other prospects.
