# What gets recorded where, and what goes to Jacques

| What | Where | When |
|---|---|---|
| Anyone **booked** or **interested** | The CRM (entry below) | Straight after the call |
| Not interested / no response | The CRM, one line with the reason | Same day |
| The walkthrough card | WhatsApp to Jacques | The evening before the walkthrough |
| Calls, owners spoken to, booked | The WhatsApp group | End of every day |
| The check export | "Export for Jacques" on the check tool, file to Jacques | Once a day |

## CRM entry: booked or interested

Give Giorgio this block to paste into the contact's notes. Also tell him which stage to set: **Demo Booked** for a booked walkthrough (until they confirm), or **Interested** with a follow-up date.

```
[Date] · [Booked walkthrough / Interested] · Giorgio
Owner: [name, role] ([confirmed / likely / not found])
Rooms: [N] · Group: [Sprint / Reviews + WhatsApp / Jacques prices it]
Walkthrough: [day, date, time] with Jacques  (or) Follow up: [date] about [what]
Google: #[position] for "guest houses in [town]", [rating] from [count] reviews, [N] new in 12 months. Rival: [name], [N] reviews
Prices on Google: [own / booking sites only / none], cheapest [price and site]
What they said: [one or two lines in their words: how they take bookings, what they do after checkout, objections]
Page sent: [page link]
```

## Card for Jacques (WhatsApp, the evening before a walkthrough)

```
Walkthrough tomorrow [time]: [Guesthouse], [Town]
Owner: [name, role] · [phone]
Rooms: [N] · Group: [Sprint / Reviews + WhatsApp / Jacques prices it]
Google: #[position], [rating] from [count] ([N] new this year). Rival: [name], [N] reviews
Booked via: [Booking.com share if they said / NightsBridge / own system / phone and email]
After checkout they: [what they said]
Watch for: [objection or worry they raised]
Page: [page link]
```

## End of day (WhatsApp group)

```
End of day [date]
Calls: [N] · Owners spoken to: [N] · Booked: [N]

Booked:
- [Guesthouse], [Town], [rooms] rooms: [day, time]
Interested (follow up):
- [Guesthouse]: [when, about what]
Tomorrow: [N] checked and ready to call
```

The three numbers show which letter of SHOWS to work on. Lots of calls but few owners means work on S and getting through. Owners but no bookings means work on H and W. Bookings but no-shows means work on the last S.
