# Messages Giorgio sends

Fill in every bracket from the check and the call. Never leave a bracket in. Giorgio sends them; you only draft.

## After booking a walkthrough (WhatsApp, straight after the call)

```
Hi [Name], it's Giorgio from ReviewTap. Thanks for your time just now.

You're booked for [day] at [time] with me and Jacques. It's a 20-minute video call, and I've sent the invite to [email].

Here's the one-page look at how [Guesthouse] shows up on Google: [page link]
Have a look before we chat. We'll go through it together.
```

## Morning of the walkthrough (WhatsApp)

```
Morning [Name]. Just a reminder that we're chatting at [time] today.

Join here: [meeting link]
If you haven't had a chance yet, here's your page again: [page link]

If the time doesn't work anymore, just reply and we'll move it.
```

## No answer after three calls (WhatsApp)

```
Hi [Name], Giorgio from ReviewTap. I tried to call about how [Guesthouse] shows up on Google Maps. Here's what I found: [page link]. Worth a 20-minute chat?
```

## No answer after three calls (email 1)

```
Subject: [Guesthouse] on Google Maps

Hi [Name]

I tried calling a couple of times, so I thought I'd send an email instead.

I was looking at guest houses in [town] on Google Maps this week. [Guesthouse] comes up [position], and [rival] comes up first with [N] reviews. Your rating is great at [rating], but Google shows [N] new reviews for you in the last year.

I've put what I found on one page for you: [page link]

Would you be open to a 20-minute call to go through it? I can do [day] at [time] or [day] at [time].

Thanks
Giorgio
ReviewTap · [Giorgio's number]
```

## Four days later, no reply (email 2, reply in the same thread)

```
Hi [Name]

Just bringing this back to the top of your inbox. Are reviews something you'd like to sort out before December, or should I check back in the new year?

Giorgio
```

No reply after that: log it as "no response" in the CRM and move on. Don't chase a third time.

## Old Facebook leads (one line, no link, no signature)

```
Subject: [Place]

Are you still looking for more Google reviews for [place]?
```
