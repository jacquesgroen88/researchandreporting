# Calls: SHOWS

What we want from every call is a walkthrough the owner actually shows up to. Don't call to sell. Call to tell them something about their own Google listing.

| | Step | What Giorgio does |
|---|---|---|
| **S** | Search | The day before, run the Google check. Have three numbers ready: where they come up, who comes up first, how many Google reviews this year. |
| **H** | Hook | Open with what he found on their listing. |
| **O** | Open question | "What happens after a guest checks out?" Then stop talking. |
| **W** | Walkthrough | Book it with two specific times, never "when suits you?" |
| **S** | Send their page | WhatsApp the confirmation with their page link, then a reminder on the morning of the call. |

After every call: which letter went wrong? That's the one to work on.

## H: Hook

- **Getting to the owner:** "Hi, it's Giorgio. Could I speak to the owner, or whoever looks after your Google reviews? It's about how the guesthouse shows up on Google Maps. Two minutes."
- **Opener:** "Hi [name], it's Giorgio from ReviewTap. I'll be quick. I was looking at guest houses in [town] on Google Maps and noticed something about [guesthouse]. Have you got two minutes?"
- **What he found (Rockview example):** "When someone searches 'guest houses in Port Edward', you come up fourth. EIGHT PALMS comes up first with 103 reviews. Your rating's great at 4.6, but you've had 2 new Google reviews this year. Google says more reviews can help your ranking, so the place that gets reviewed more gets seen first."

Only the numbers from the check. Never rounded up.

## O: Open question

"What happens at the moment after a guest checks out? Does anyone ask them for a Google review?" Let them answer. Then: "How many came in last month?" Somewhere in here: "How many rooms do you have?"

## W: Walkthrough

"We set that up for guesthouses so every guest gets asked. I'd like to show you your Google listing next to [rival] on a 20-minute call with Jacques, who runs the setup. Is Tuesday at 10 or Wednesday at 2 better for you?"

## When they push back

- **"Send me some information."** "Happy to. The most useful thing is your own Google page, and I'll WhatsApp it now. It makes more sense with someone walking you through it, though. Shall I pencil in Thursday at 10? If it's not useful, you can cancel."
- **"How much is it?"** "Every place is different. We have guesthouses spending about R500 a month and others spending R8,000 a month. Where you'd sit depends on your rooms and what we find, and that's exactly what the 20 minutes is for." Then back to the two times.
- **"We're too busy, it's nearly December."** "That's exactly why. December is when you have the most guests to ask. To be live and ready for December, we'd need to start by 13 November."
- **"Most of our bookings come through Booking.com."** "How many would you say? And what does that commission cost you in a year?" Don't promise to fix it.
- **"We already ask for reviews."** "Great. Google shows [N] new ones this year. Is that about what you'd expect?"
- **"Not interested."** "Fair enough. Can I ask, is it that reviews aren't a priority, or just the timing?" If it's the timing, ask when to call back and log it.

## The walkthrough itself

| Part | Who | Time |
|---|---|---|
| Their page, next to the place beating them (share screen) | Giorgio | 10 min |
| Questions: how they get bookings, what Booking.com costs, what happens after checkout | Giorgio | 5 min |
| The offer, the guarantee, the bonus and the ask | Jacques | 15 min |
| Follow-up and the CRM | Giorgio | |
