# The pre-call Google check

Run this in the browser for each guesthouse Giorgio gives you. After step 11, give him a call card for each (format in SKILL.md).

Please do a pre-call Google check for ReviewTap, using this browser. Read public pages only: don't sign in to anything, don't click adverts, don't message or book anything.

Guesthouses to check (Name, Town):
(the list Giorgio gives you, one "Name, Town" per line)

For each guesthouse, one at a time:

1. Open https://www.google.com/maps/search/guest+houses+in+TOWN?hl=en (put the town in, spaces as +). Scroll the list on the left until about 20 places show or it says you've reached the end.
2. Count down the list, skipping anything marked "Sponsored". Note where the guesthouse comes (1 = first non-sponsored place). If it isn't in the first 20, use 99. Note the name, star rating and review count of the first 3 non-sponsored places, and the names of any sponsored ones.
3. Do the same for https://www.google.com/maps/search/accommodation+in+TOWN?hl=en. Only their position is needed.
4. Open their own listing by searching https://www.google.com/maps/search/NAME+TOWN?hl=en. Don't click it from the earlier lists: that view can hide the Reviews tab. If a list appears, open the one that matches.
5. Note the star rating and number of reviews at the top of the listing.
6. Under "Compare prices", if it's there, note each site and its price. Price is "own" if their own website or "Official site" shows a price, "ota" if only booking sites show (Booking.com, Bluepillow and so on), "none" if there are no prices. Note the cheapest, like "R936 on Bluepillow".
7. Click the Reviews tab, open the sort menu ("Most relevant") and choose "Newest". Only count reviews "on Google"; skip ones on Tripadvisor or other sites. Note how old the newest Google review is, how many of the 5 newest Google reviews have a "Response from the owner", and how many Google reviews are under 12 months old (scroll until you pass 12 months). While you're there, note the name owners sign their replies with, if they do.
8. Find the owner. Look, in this order, at: their website's About, Contact or "Your hosts" page; how owner replies are signed on Google; the host name on their Booking.com, Airbnb, LekkeSlaap or SafariNow listing; Tripadvisor management responses; their Facebook page's About section. Note the name, their role (owner, manager, host), and where you found it. Only use what the business itself publishes: no personal social profiles, home addresses or ID numbers. If two sources agree, it's "confirmed". If one source says so, it's "likely". If nothing says so, write "not found". Never guess a name.
9. Open this link with the values filled in (URL-encode each one, leave a value empty if you couldn't find it):
   https://jcereports.netlify.app/google-check-f2c85f/precheck-5d17a3.html?src=claude&biz=NAME&town=TOWN&p1=&p2=&t1n=&t1r=&t1c=&t2n=&t2r=&t2c=&t3n=&t3r=&t3c=&rating=&count=&newest=&replies=&price=&cheap=&notes=
   - p1 = position in "guest houses in", p2 = position in "accommodation in". Numbers only, 99 = not in the top 20.
   - t1n/t1r/t1c = name, rating, review count of the first place in "guest houses in"; t2 and t3 the same for the next two.
   - newest must be exactly one of: Under 1 month ago / 1 to 3 months ago / 3 to 12 months ago / Over a year ago / No Google reviews
   - replies = 0 to 5. price = own, ota or none.
   - notes = "Owner: NAME, ROLE (SOURCE, confirmed/likely)" or "Owner: not found", the sponsored names, "Google reviews in the last 12 months: N", and anything odd (an unanswered bad review, old photos, wrong phone number).
10. On that page, check the boxes match what you saw, then click "Save to my list". Copy the first point under "What to lead with".
11. Click "Make their page". Their ReviewTap page opens in a new tab. Check the name, rating and position on it match what you saw, then copy that tab's full address: that's the link I send them.

Rules:
- If Google shows an "unusual traffic" or "I'm not a robot" page, stop and tell me. Never try to get past it.
- Never guess a number or a name. If you can't find something, leave it empty and say so.

When all are done, give me a short table: guesthouse, owner (and how sure), position, rating and reviews, newest Google review, owner replies, prices, and the point to lead with. Under the table, list each guesthouse with its page link on its own line, so I can copy them. Then remind me to click "Export for Jacques" on the check tool and send him the file.
