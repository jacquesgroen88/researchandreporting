# Start here: setting up your ReviewTap Claude

This folder teaches your Claude the whole accommodation process: the check, finding the owner, making each prospect's page, what to say, and what to send where. Set it up once, then just talk to it.

## Set it up (5 minutes, pick one)

**Option A: as a Skill (best).** In Claude, open **Settings → Capabilities → Skills**, click **Upload skill**, and choose the file `reviewtap-accommodation.zip`, exactly as you downloaded it. Claude then uses it on its own whenever you talk about prospects.

**Option B: as a Project.** In Claude, create a new Project called **ReviewTap Accommodation**.
1. Open `SKILL.md`, copy everything below the second `---` line, and paste it into the Project's **instructions**.
2. Upload every file in `references/` to the Project's **files**.
3. Always start your prospecting chats inside that Project.

The Google check needs Claude to use your browser, so use it where **Claude in Chrome** is switched on.

## Your first test (do this before using it for real)

Say: **"Check this one: Rockview Guest House, Port Edward"**

Then compare what it gives you against Google Maps yourself: the position, the rating, the reviews and the owner. If they match, you're ready. If something's off, tell Jacques.

## What to say to it

| Say | It does |
|---|---|
| "Check these for tomorrow: Name, Town; Name, Town ..." | Runs the Google check, finds the owner, makes each page, gives you call cards |
| "Find the owner of [Guesthouse], [Town]" | Owner, role, where it found it, how sure |
| "I booked [Guesthouse] for Thursday 10:00" | CRM entry, confirmation WhatsApp, Jacques's card |
| "[Guesthouse] is interested, call back Monday" | CRM entry with the follow-up |
| "No answer from [Guesthouse]" | Counts the tries; after 3, writes the email and WhatsApp |
| "What do I say if they ask the price?" | The answer, in a line |
| "End of day: 42 calls, 11 owners" | The WhatsApp group message |
| "Where am I?" | Today's log: who's done, who's next |

It drafts everything. You check it and send it.

## Links

- Check tool: https://jcereports.netlify.app/google-check-f2c85f/precheck-5d17a3.html
- Your list (only for you): https://jcereports.netlify.app/google-check-f2c85f/list-8e048fc2.html
- The playbook: https://jcereports.netlify.app/giorgio-playbook-1ceb4a/
